﻿using guiP1B.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace guiP1B
{
    public partial class Form1 : Form
    {

        Crud miCrud = new Crud();
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonSaludar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("HOla te saludo desde el formulario 👊👊👊");
        }

        private void buttonBuscar_Click(object sender, EventArgs e)
        {
            textBoxEstudiante.Text = miCrud.MostrarInformacion(textBoxCarnet.Text);
        }

        private void buttonCrear_Click(object sender, EventArgs e)
        {
            string nombre = textBoxEstudiante.Text;
            string carnet = textBoxCarnet.Text;
            string email = textBoxEmail.Text;
            string seccion = textBoxSeccion.Text;
            string respuesta = miCrud.AgregarAlumno(carnet, nombre, email, seccion);
            MessageBox.Show(respuesta);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Crear una instancia del reproductor de video
            System.Diagnostics.Process process = new System.Diagnostics.Process();

            // Configurar el proceso para abrir el video con el reproductor predeterminado
            process.StartInfo.FileName = "https://drive.google.com/file/d/1zzuvK9p0u2n-yemHffos5C_aBiFXtJue/view?usp=sharing"; // Reemplaza con la ruta de tu video
            process.StartInfo.UseShellExecute = true;

            // Iniciar el proceso para reproducir el video
            process.Start();
        }

        private void Cerrar_Click(object sender, EventArgs e)
        {
            // Cierra la aplicación completamente
            this.Close();


        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            DialogResult response = MessageBox.Show(
                "Are you sure you want to exit the application?",
                "Exit application",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (response == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

    }
}